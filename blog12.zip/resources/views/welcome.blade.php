@extends('header.header')
@section('content')
 
	<router-view></router-view>
 
 
@endsection